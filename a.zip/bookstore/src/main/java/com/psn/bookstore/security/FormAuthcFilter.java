package com.psn.bookstore.security;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.util.StringUtils;
import org.apache.shiro.web.filter.authc.FormAuthenticationFilter;
import org.apache.shiro.web.util.WebUtils;

public class FormAuthcFilter extends FormAuthenticationFilter{
	
	/**
	 * 账号token
	 */
	@Override
	public AuthenticationToken createToken(ServletRequest request, ServletResponse response) {
		String username = WebUtils.getCleanParam(request, "username");
		String password = WebUtils.getCleanParam(request, "password");
		return new UsernamePasswordToken(username, password);
	}
	
	protected boolean executeLogin(ServletRequest request, ServletResponse response) throws Exception {
		AuthenticationToken token = createToken(request, response);
		if (token == null) {
			String e1 = "createToken method implementation returned null. A valid non-null AuthenticationToken must be created in order to execute a login attempt.";
			throw new IllegalStateException(e1);
		} else {
			try {
				Subject e = this.getSubject(request, response);
				e.login(token);
				return this.onLoginSuccess(token, e, request, response);
			} catch (AuthenticationException arg4) {
				return this.onLoginFailure(token, arg4, request, response);
			}
		}
	}
	
}
