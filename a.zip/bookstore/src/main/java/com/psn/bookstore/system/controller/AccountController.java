package com.psn.bookstore.system.controller;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class AccountController {
	
	@RequestMapping(value="login" )
	public String login() {
		System.out.println("this is login controller");
		return "login";
	}
	
	/*@RequestMapping(value="login" , method={RequestMethod.POST})
	@ResponseBody
	public String login(String username, String password) {
		Subject subject = SecurityUtils.getSubject();
		AuthenticationToken usernamePasswordToken = new UsernamePasswordToken(username, password);
		try
		{
			subject.login(usernamePasswordToken);
		}catch (Exception e) {
			e.printStackTrace();
			return "failed";
		}
		return "success";
	}*/
	
	@RequestMapping("main")
	public String main() {
		System.out.println("this is main page.");
		return "main";
	}
	
}
